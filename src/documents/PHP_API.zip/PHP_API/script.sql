/**
 * Author:  Alessandro
 * Created: 21/04/2025
 */
create database if not exists api_produto;
use api_produto;

drop table produto;
create table produto(
    pro_id int not null primary key auto_increment,
    pro_descricao varchar(50) null,
    pro_preco decimal (12,2) not null default 0.00,
    pro_validade date not null
);

INSERT INTO `produto` (`pro_id`, `pro_descricao`, `pro_preco`, `pro_validade`) VALUES
(1, 'Batata', '2.39', '2025-06-28'),
(2, 'Cebola', '1.19', '2025-07-15'),
(3, 'Arroz', '21.75', '2025-09-11'),
(4, 'Feijão', '8.29', '2025-10-14'),
(5, 'Abacate', '9.68', '2024-12-24'),
(6, 'Cenoura', '2.15', '2025-05-24'), 
(7, 'Tomate', '3.98', '2025-05-01');