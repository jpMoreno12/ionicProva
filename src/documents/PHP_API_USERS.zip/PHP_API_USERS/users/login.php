<?php
include("../conexao.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



// Responder requisição preflight OPTIONS e sair
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json');

require("../conexao.php");

$postdata = file_get_contents("php://input");
$request = json_decode($postdata);

if (!$request || !isset($request->email) || !isset($request->senha)) {
    http_response_code(400);
    echo json_encode(["erro" => "Email e senha são obrigatórios"]);
    exit;
}

$email = $request->email;
$senha = $request->senha;

$stmt = $conexao->prepare("SELECT id, nome, email FROM users WHERE email = ? AND senha = ?");
$stmt->bind_param("ss", $email, $senha);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $user = $result->fetch_assoc()) {
    http_response_code(200);
    echo json_encode([
        "message" => "Login OK",
        "usuario" => [
            "id" => $user['id'],
            "nome" => $user['nome'],
            "email" => $user['email']
        ]
    ]);
} else {
    http_response_code(401);
    echo json_encode(["erro" => "Email ou senha incorretos"]);
}
