<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header("Location: inserir.php");
    //echo "POST";
}
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    header("Location: listar.php");
    //echo "GET";
}
if ($_SERVER["REQUEST_METHOD"] == "PUT") {
echo "PUT";
}
if ($_SERVER["REQUEST_METHOD"] == "DELETE") {
echo "DELETE";
}