-- Criar o banco de dados
CREATE DATABASE IF NOT EXISTS api_users CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Usar o banco de dados
USE api_users;

-- Criar a tabela users
CREATE TABLE IF NOT EXISTS users (
    id INT(11) NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    senha VARCHAR(100) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY (email)
);

-- Inserir usuários de teste
INSERT INTO users (nome, email, senha) VALUES
('João Silva', 'joao@email.com', '123456'),
('Maria Oliveira', 'maria@email.com', 'abcdef'),
('Carlos Souza', 'carlos@email.com', 'senha123');
