<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$erro;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        if (!empty($request->api_key)) {
            $API_KEY = $request->api_key;
            if ($API_KEY == "123") {
                http_response_code(200);
                $retorno = array("mensagem" => "Funcionou");
                echo json_encode($retorno);
            } else {
                header("HTTP/1.1 500 Erro");
                $erro = array("mensagem" => "Chave da API Inválida");
                echo json_encode($erro);
            }
        } else {
            header("HTTP/1.1 500 Erro");
            $erro = array("mensagem" => "Favor Informar a chave da API");
            echo json_encode($erro);
        }
    } catch (Exception $ex) {
        echo json_encode(["erro" => $ex]);
    }
}

//echo json_encode(["message" => "OK"]);
